<?php

declare(strict_types=1);

require __DIR__ . '/../src/TarneebEngine.php';

use Warqna\Tarneeb\TarneebEngine;
use Warqna\Tarneeb\TarneebException;

function assert_true(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException('Assertion failed: ' . $message);
    }
}

$engine = new TarneebEngine();

// Target score options must be exactly 31 / 41 / 61.
assert_true($engine->targetScoreOptions() === [31, 41, 61], 'target score options should be 31, 41, 61');
foreach ([31, 41, 61] as $target) {
    $quick = $engine->newGameWithTarget([
        ['id' => 't1' . $target, 'name' => 'Bot 1', 'bot' => true],
        ['id' => 't2' . $target, 'name' => 'Bot 2', 'bot' => true],
        ['id' => 't3' . $target, 'name' => 'Bot 3', 'bot' => true],
        ['id' => 't4' . $target, 'name' => 'Bot 4', 'bot' => true],
    ], $target, 9000 + $target);
    assert_true((int)$quick['rules']['targetScore'] === $target, "target {$target} should be accepted");
}
try {
    $engine->newGameWithTarget([
        ['id' => 'x1', 'name' => 'Bot 1', 'bot' => true],
        ['id' => 'x2', 'name' => 'Bot 2', 'bot' => true],
        ['id' => 'x3', 'name' => 'Bot 3', 'bot' => true],
        ['id' => 'x4', 'name' => 'Bot 4', 'bot' => true],
    ], 51, 777);
    throw new RuntimeException('Expected invalid target score exception');
} catch (TarneebException $e) {
    assert_true($e->codeKey === 'invalid_target_score', 'invalid target score expected');
}

$state = $engine->newGame([
    ['id' => 'b1', 'name' => 'Bot 1', 'bot' => true],
    ['id' => 'b2', 'name' => 'Bot 2', 'bot' => true],
    ['id' => 'b3', 'name' => 'Bot 3', 'bot' => true],
    ['id' => 'b4', 'name' => 'Bot 4', 'bot' => true],
], 20260630, ['targetScore' => 31]);

// Test deal integrity.
$allCards = [];
for ($s = 0; $s < 4; $s++) {
    assert_true(count($state['hands'][$s]) === 13, "seat {$s} should have 13 cards");
    foreach ($state['hands'][$s] as $card) {
        $allCards[] = $card;
    }
}
assert_true(count(array_unique($allCards)) === 52, 'deck should have 52 unique cards');

// Let all bots play until game over.
$guard = 0;
while (!$engine->isFinished($state) && $guard < 2000) {
    $previousHash = $engine->stateHash($state);
    $state = $engine->autoPlayBotsAndAway($state, 20);
    if ($engine->isFinished($state)) {
        break;
    }
    if ($previousHash === $engine->stateHash($state)) {
        throw new RuntimeException('Bot autoplay stalled at phase ' . $state['phase'] . ' seat ' . $state['currentSeat']);
    }
    if ($state['phase'] === 'round_end') {
        $state = $engine->nextRound($state);
    }
    $guard++;
}

assert_true(isset($state['scores'][0], $state['scores'][1]), 'scores should exist');
assert_true(count($state['events']) > 0, 'events should be recorded');

// Test illegal card validation: human tries to play while not his turn or wrong phase.
$human = $engine->newGame([
    ['id' => 'u1', 'name' => 'User 1', 'bot' => false],
    ['id' => 'u2', 'name' => 'User 2', 'bot' => false],
    ['id' => 'u3', 'name' => 'User 3', 'bot' => false],
    ['id' => 'u4', 'name' => 'User 4', 'bot' => false],
], 44);
try {
    $engine->playCard($human, 'u1', $human['hands'][0][0]);
    throw new RuntimeException('Expected wrong phase exception');
} catch (TarneebException $e) {
    assert_true($e->codeKey === 'wrong_phase', 'wrong phase expected');
}

echo "All Tarneeb engine tests passed. Target scores 31/41/61 are supported.\n";
