<?php

// Example only: copy src/TarneebEngine.php into app/Services/TarneebEngine.php
// or load it with Composer/classmap, then store $state as JSON in DB/Redis.

use Warqna\Tarneeb\TarneebEngine;
use Warqna\Tarneeb\TarneebException;

final class TarneebRoomController
{
    public function createRoom(): array
    {
        $engine = new TarneebEngine();
        $targetScore = (int)request('target_score', 41); // allow 31, 41, or 61 only.
        $state = $engine->newGameWithTarget([
            ['id' => 'user_1', 'name' => 'Player 1', 'bot' => false],
            ['id' => 'bot_2', 'name' => 'Bot 2', 'bot' => true],
            ['id' => 'bot_3', 'name' => 'Bot 3', 'bot' => true],
            ['id' => 'bot_4', 'name' => 'Bot 4', 'bot' => true],
        ], targetScore: $targetScore, seed: random_int(1, PHP_INT_MAX));

        // Room::create(['engine_state' => json_encode($state, JSON_UNESCAPED_UNICODE)]);
        return $state;
    }

    public function action(array $state, string $userId, string $action, array $payload): array
    {
        $engine = new TarneebEngine();
        try {
            $state = match ($action) {
                'bid' => $engine->bid($state, $userId, $payload['amount'] ?? null),
                'choose_trump' => $engine->chooseTrump($state, $userId, (string)$payload['suit']),
                'play_card' => $engine->playCard($state, $userId, (string)$payload['card']),
                'away' => $engine->setAway($state, $userId, true),
                'back' => $engine->setAway($state, $userId, false),
                'leave' => $engine->leave($state, $userId),
                'rejoin' => $engine->rejoin($state, $userId),
                'next_round' => $engine->nextRound($state),
                default => throw new RuntimeException('Unknown action'),
            };
            $state = $engine->autoPlayBotsAndAway($state);
            // Save JSON state again.
            return ['ok' => true, 'state' => $engine->playerView($state, $userId)];
        } catch (TarneebException $e) {
            return ['ok' => false, 'message' => $e->getMessage(), 'code' => $e->codeKey, 'context' => $e->context];
        }
    }
}
