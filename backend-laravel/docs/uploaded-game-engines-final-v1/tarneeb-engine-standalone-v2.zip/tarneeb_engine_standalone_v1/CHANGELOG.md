# Changelog

## v2

- إضافة دعم رسمي ومقيد للنتيجة النهائية: 31 / 41 / 61.
- إضافة `newGameWithTarget($players, $targetScore)`.
- إضافة `targetScoreOptions()`.
- رفض أي نتيجة غير مدعومة برسالة واضحة `invalid_target_score`.
- تحسين README و demo و tests.
- تحديث إصدار الحالة إلى `1.1.0`.

## v1

- أول نسخة من محرك الطرنيب المستقل.
