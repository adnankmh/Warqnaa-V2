<?php

declare(strict_types=1);

require __DIR__ . '/src/TarneebEngine.php';

use Warqna\Tarneeb\TarneebEngine;
use Warqna\Tarneeb\TarneebException;

$engine = new TarneebEngine();

// اختر النتيجة النهائية من هنا: 31 أو 41 أو 61.
$targetScore = 41;

$state = $engine->newGameWithTarget([
    ['id' => 'u1', 'name' => 'أنت', 'bot' => false],
    ['id' => 'bot2', 'name' => 'Bot 2', 'bot' => true],
    ['id' => 'bot3', 'name' => 'Bot 3', 'bot' => true],
    ['id' => 'bot4', 'name' => 'Bot 4', 'bot' => true],
], targetScore: $targetScore, seed: 12345, rules: [
    'turnSeconds' => 8,
]);

echo "Game: {$state['id']}\n";
echo "Target score: {$state['rules']['targetScore']}\n";
echo "Allowed target scores: " . implode(', ', $engine->targetScoreOptions()) . "\n";
echo "Phase: {$state['phase']} | Current seat: {$state['currentSeat']}\n";

try {
    // Let bots act until the human player turn.
    $state = $engine->autoPlayBotsAndAway($state);

    $view = $engine->playerView($state, 'u1');
    echo "Your seat: {$view['you']}\n";
    echo "Your hand:\n";
    foreach ($view['hands'][$view['you']] as $card) {
        $info = $engine->cardInfo($card);
        echo " - {$info['labelAr']} ({$card})\n";
    }

    // Example: if it is your turn to bid, bid the next valid number or pass.
    if ($state['phase'] === 'bidding' && $state['currentSeat'] === $view['you']) {
        $currentBid = (int)($state['bid']['amount'] ?? 0);
        $nextBid = max(7, $currentBid + 1);
        if ($nextBid <= 13) {
            $state = $engine->bid($state, 'u1', $nextBid);
            echo "You bid {$nextBid}.\n";
        } else {
            $state = $engine->bid($state, 'u1', null);
            echo "You passed.\n";
        }
    }

    echo "Public view without hidden hands:\n";
    echo json_encode($engine->publicView($state), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . PHP_EOL;
} catch (TarneebException $e) {
    echo "Tarneeb error: {$e->getMessage()} ({$e->codeKey})\n";
}
