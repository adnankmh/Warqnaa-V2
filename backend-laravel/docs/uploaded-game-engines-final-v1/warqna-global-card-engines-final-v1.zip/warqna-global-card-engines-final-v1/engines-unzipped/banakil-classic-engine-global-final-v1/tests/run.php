<?php
require_once __DIR__ . '/../src/BanakilClassicEngine.php';
function ok($cond, $msg) { if (!$cond) { fwrite(STDERR, "FAIL: $msg\n"); exit(1); } }
$engine = new BanakilClassicEngine();
$info = $engine->gameInfo();
foreach ($info['players'] as $count) {
    $players=[]; for($i=1;$i<=$count;$i++) $players[]=['id'=>'p'.$i,'name'=>'P'.$i,'bot'=>true];
    $state=$engine->newGame($players, ['seed'=>1000+$count]);
    ok(count($state['players'])===$count, 'player count');
    ok(!empty($state['antiCheat']['lastHash']), 'hash exists');
    $view=$engine->playerView($state,'p1');
    foreach($view['hands'] as $pid=>$hand) if($pid !== 'p1') ok(isset($hand['count']), 'opponent hand hidden');
    for($m=0;$m<60 && !$state['gameOver'];$m++) {
        $pid=$state['players'][$state['currentIndex']]['id'];
        $actions=array_values(array_filter($engine->availableActions($state,$pid), fn($a)=>($a['type']??'')!=='wait'));
        if(!$actions) break;
        $state=$engine->applyAction($state,$pid,$actions[0]);
        ok(!empty($state['antiCheat']['lastHash']), 'hash after move');
    }
    $json=$engine->serialize($state);
    $again=$engine->deserialize($json);
    ok($again['engine']===$state['engine'], 'serialize roundtrip');
}
echo "All tests passed for بناكل كلاسيك (banakil-classic)\n";
