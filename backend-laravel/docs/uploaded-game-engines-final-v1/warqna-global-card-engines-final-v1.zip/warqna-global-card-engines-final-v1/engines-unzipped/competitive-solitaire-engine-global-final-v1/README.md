# 🃁 سوليتير تنافسي — Global Final Engine v1

محرك سوليتير تنافسي 2-4 لاعبين مع Stock/Waste/Foundation وحساب سرعة وإنجاز.

## الجاهزية
- محرك مستقل عن Laravel وWarqna.
- Server-authoritative: كل حركة يتم التحقق منها داخل المحرك.
- Replay Events لكل حركة.
- State Hash لاكتشاف التلاعب.
- Player View يخفي أوراق الخصوم.
- Spectator View لا يكشف أي يد.
- Demo و Tests جاهزة.
- قابل للدمج مع Laravel أو Node/WebSocket أو أي تطبيق آخر.

## التشغيل
```bat
cd competitive-solitaire-engine-global-final-v1
C:\xampp\php\php.exe tests\run.php
C:\xampp\php\php.exe examples\demo.php
```

## أهم الواجهات البرمجية
```php
$engine = new CompetitiveSolitaireEngine();
$state = $engine->newGame($players, ['seed' => 12345]);
$actions = $engine->availableActions($state, 'p1');
$state = $engine->applyAction($state, 'p1', $actions[0]);
$view = $engine->playerView($state, 'p1');
$json = $engine->serialize($state);
```

## ملاحظة مهمة
هذه حزمة محرك قوانين ومنطق، وليست واجهة رسومية. الدمج مع تطبيقك يحتاج صفحة طاولة/كروت/WebSocket وربط الأزرار مع `applyAction`.
