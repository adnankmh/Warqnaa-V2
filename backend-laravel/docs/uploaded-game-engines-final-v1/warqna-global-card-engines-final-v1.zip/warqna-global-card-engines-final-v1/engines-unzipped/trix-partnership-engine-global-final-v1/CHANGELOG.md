# CHANGELOG

## Global Final v1
- بناء محرك مستقل للعبة تركس شراكة.
- إضافة `newGame`, `availableActions`, `applyAction`.
- إضافة Player/Spectator views.
- إضافة Replay Events و State Hash.
- إضافة Demo و Tests و Integration docs.
