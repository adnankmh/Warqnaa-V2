<?php
require_once __DIR__ . '/../src/TrixEngine.php';
$engine = new TrixEngine();
$info = $engine->gameInfo();
$players = [];
$count = $info['players'][0];
for ($i=1; $i<=$count; $i++) $players[] = ['id'=>'p'.$i, 'name'=>'Player '.$i, 'bot'=>$i>1];
$state = $engine->newGame($players, ['seed'=>12345]);
for ($i=0; $i<25 && !$state['gameOver']; $i++) {
    $pid = $state['players'][$state['currentIndex']]['id'];
    $actions = array_values(array_filter($engine->availableActions($state, $pid), fn($a)=>($a['type']??'') !== 'wait'));
    if (!$actions) break;
    $state = $engine->applyAction($state, $pid, $actions[0]);
}
echo $info['emoji'].' '.$info['title_ar']." demo OK\n";
echo "Phase: ".$state['phase']."\n";
echo "Events: ".count($state['events'])."\n";
echo "Hash: ".$state['antiCheat']['lastHash']."\n";
