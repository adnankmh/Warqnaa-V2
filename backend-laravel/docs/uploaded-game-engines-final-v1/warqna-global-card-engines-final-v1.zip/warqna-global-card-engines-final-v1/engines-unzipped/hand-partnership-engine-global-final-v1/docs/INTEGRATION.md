# دمج هاند شراكة مع أي تطبيق

1. انسخ مجلد `src` داخل مشروعك أو ضعه كحزمة مستقلة.
2. خزن `$state` في قاعدة البيانات أو Redis بصيغة JSON.
3. عند ضغط اللاعب زرًا في الواجهة، أرسل action إلى السيرفر.
4. السيرفر يستدعي:

```php
$state = $engine->applyAction($state, $playerId, $action);
```

5. أرسل `playerView` لكل لاعب عبر WebSocket.

## أحداث WebSocket مقترحة
- `game.created`
- `action.applied`
- `state.updated`
- `illegal.move`
- `round.scored`
- `game.finished`
