# Warqna Global Card Engines Final v1

حزمة محركات ألعاب ورق مستقلة ونهائية كقاعدة احترافية للدمج مع أي تطبيق.

## المحتوى
- `engines-zipped/`: كل محرك داخل ملف ZIP مستقل.
- `engines-unzipped/`: نفس المحركات مفتوحة للتصفح والتعديل.
- `MANIFEST.json`: قائمة المحركات ونتائج الفحص.

## التشغيل
افتح أي محرك ثم شغل:

```bat
C:\xampp\php\php.exe tests\run.php
C:\xampp\php\php.exe examples\demo.php
```

## ملاحظات
هذه محركات منطق وقوانين وليست واجهات رسومية. واجهة الطاولة، صور الكروت، WebSocket، الصوت، والدردشة يتم ربطها فوق هذه المحركات.
